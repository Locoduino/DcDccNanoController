var searchData=
[
  ['commanders_5fevent_5ftype',['COMMANDERS_EVENT_TYPE',['../Events_8h.html#a36239a7eea6194f04e73e80d7419490c',1,'Events.h']]],
  ['commanders_5fmove_5ftype',['COMMANDERS_MOVE_TYPE',['../Events_8h.html#a347ec2e7ad5bc98b641a887ce34cc2ba',1,'Events.h']]]
];
