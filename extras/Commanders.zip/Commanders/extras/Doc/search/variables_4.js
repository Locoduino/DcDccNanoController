var searchData=
[
  ['lastbuttonstate',['LastButtonState',['../structEventPin.html#abb37cc6189d84d6a11ab4b7a46337bd8',1,'EventPin']]],
  ['lastdebouncetime',['LastDebounceTime',['../structEventPin.html#a21a693bb91243b2ad19feebecfc474fb',1,'EventPin']]]
];
