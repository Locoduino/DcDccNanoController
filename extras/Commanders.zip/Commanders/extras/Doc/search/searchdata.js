var indexSectionsWithContent =
{
  0: "abcdeghilnoprstu",
  1: "bcdeint",
  2: "ces",
  3: "abcdeghilnprst",
  4: "bdeilnopst",
  5: "c",
  6: "c",
  7: "cgnsu",
  8: "h"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enums",
  6: "Enum Values",
  7: "Macros",
  8: "Pages"
};

